### What model/animation is causing this issue? (please include .blend file with packed textures)


### Steps to reproduce?
#### If this is a model export please include the exact changes made in blender.


### What version of the tool are you using?


### What is your blender version?


### Additional information, feel free to include a few screenshots or extra notes.


